import React, { useState } from 'react';
import { Plus, Minus, X, ArrowDownCircle, ArrowUpCircle, ShoppingCart, Printer, Check } from 'lucide-react';
import { C, fmtNum } from '../lib/helpers.js';
import { Field, inputStyle, primaryBtn, secondaryBtn, EmptyHint, Modal } from '../ui.jsx';
import ProductPicker from './ProductPicker.jsx';

const MOTIVOS = {
  entrada: [['compra', 'Compra a proveedor'], ['devolucion', 'Devolución de cliente'], ['ajuste', 'Ajuste de inventario']],
  salida: [['venta', 'Venta'], ['merma', 'Merma / daño'], ['ajuste', 'Ajuste de inventario']],
};

export default function RegistrarMovimiento({ type, products, canEdit, userEmail, money, onConfirm, notify }) {
  const isEntrada = type === 'entrada';
  const [cart, setCart] = useState([]); // {productId, nombre, sku, unidad, unitPrice, stock}
  const [motivo, setMotivo] = useState(MOTIVOS[type][0][0]);
  const [note, setNote] = useState('');
  const [receipt, setReceipt] = useState(null);
  const [confirming, setConfirming] = useState(false);

  function addToCart(p) {
    setCart(c => {
      const existing = c.find(i => i.productId === p.id);
      if (existing) return c.map(i => i.productId === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { productId: p.id, nombre: p.nombre, sku: p.sku, unidad: p.unidad, unitPrice: isEntrada ? p.costo : p.precio_venta, qty: 1, stock: p.stock }];
    });
  }
  function changeQty(productId, delta) {
    setCart(c => c.map(i => i.productId === productId ? { ...i, qty: i.qty + delta } : i).filter(i => i.qty > 0));
  }
  function removeItem(productId) { setCart(c => c.filter(i => i.productId !== productId)); }

  const total = cart.reduce((s, i) => s + i.qty * i.unitPrice, 0);

  async function confirm() {
    if (cart.length === 0) { notify('Agrega al menos un producto', 'error'); return; }
    if (!isEntrada) {
      const short = cart.find(i => i.qty > i.stock);
      if (short) { notify(`Solo hay ${fmtNum(short.stock)} ${short.unidad} de "${short.nombre}"`, 'error'); return; }
    }
    setConfirming(true);
    const ok = await onConfirm({ items: cart.map(i => ({ productId: i.productId, qty: i.qty })), type, motivo, note });
    setConfirming(false);
    if (ok !== false) {
      setReceipt({ items: cart, motivo, note, date: new Date(), total, type });
      setCart([]); setNote('');
    }
  }

  if (!canEdit) {
    return <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 13, padding: 30, textAlign: 'center' }}>
      <EmptyHint text="No tienes permiso para registrar movimientos. Pide a un administrador que te dé rol de Editor." />
    </div>;
  }

  return (
    <div className="cart-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 13, padding: 16 }}>
        <div style={{ fontWeight: 700, fontFamily: 'Space Grotesk, sans-serif', fontSize: 14.5, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
          {isEntrada ? <ArrowDownCircle size={18} color={C.ok} /> : <ArrowUpCircle size={18} color={C.danger} />}
          {isEntrada ? 'Registrar entrada' : 'Registrar salida'}
        </div>
        <ProductPicker products={products} onAdd={addToCart} />

        <div style={{ marginTop: 14 }}>
          {cart.length === 0 ? <EmptyHint text="Busca arriba y haz clic en un producto para agregarlo al carrito." /> : cart.map(i => (
            <div key={i.productId} className="flex items-center justify-between" style={{ padding: '10px 0', borderBottom: `1px solid ${C.border}`, gap: 8 }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 13.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{i.nombre}</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft }}>{money(i.unitPrice)} c/u · {money(i.qty * i.unitPrice)}</div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => changeQty(i.productId, -1)} style={stepBtn}><Minus size={13} /></button>
                <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontWeight: 700, minWidth: 26, textAlign: 'center' }}>{fmtNum(i.qty)}</span>
                <button onClick={() => changeQty(i.productId, 1)} style={stepBtn}><Plus size={13} /></button>
                <button onClick={() => removeItem(i.productId)} style={{ ...stepBtn, color: C.danger, marginLeft: 4 }}><X size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 13, padding: 16, alignSelf: 'start' }}>
        <div className="flex items-center gap-2" style={{ marginBottom: 12, fontWeight: 700, fontFamily: 'Space Grotesk, sans-serif', fontSize: 14.5 }}>
          <ShoppingCart size={16} /> Carrito ({cart.length})
        </div>
        <Field label="Motivo">
          <select style={inputStyle} value={motivo} onChange={e => setMotivo(e.target.value)}>
            {MOTIVOS[type].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </Field>
        <Field label="Nota (opcional)"><input style={inputStyle} value={note} onChange={e => setNote(e.target.value)} placeholder="Ej. Cliente, factura #234" /></Field>
        <div className="flex items-center justify-between" style={{ padding: '10px 0', borderTop: `1px solid ${C.border}`, marginBottom: 12, fontWeight: 700 }}>
          <span>Total</span><span>{money(total)}</span>
        </div>
        <button onClick={confirm} disabled={cart.length === 0 || confirming} style={{ ...primaryBtn, width: '100%', justifyContent: 'center', opacity: (cart.length === 0 || confirming) ? .5 : 1, background: isEntrada ? C.brand : C.danger }}>
          <Check size={15} /> {confirming ? 'Guardando…' : isEntrada ? 'Confirmar entrada' : 'Confirmar venta / salida'}
        </button>
      </div>

      {receipt && <ReciboModal receipt={receipt} userEmail={userEmail} money={money} onClose={() => setReceipt(null)} />}
    </div>
  );
}
const stepBtn = { width: 26, height: 26, borderRadius: 7, border: `1px solid ${C.border}`, background: '#fff', color: C.ink, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' };

function ReciboModal({ receipt, userEmail, money, onClose }) {
  return (
    <Modal title={receipt.type === 'entrada' ? 'Recibo de entrada' : 'Mini factura de venta'} onClose={onClose} width={420}>
      <div id="receipt-print">
        <div style={{ fontSize: 12.5, color: C.inkSoft, marginBottom: 10 }}>
          {receipt.date.toLocaleString('es-NI')} · Atendido por {userEmail}
          {receipt.note && <div>Nota: {receipt.note}</div>}
        </div>
        <table>
          <thead><tr><th>Producto</th><th>Cant.</th><th>P. unit.</th><th>Subtotal</th></tr></thead>
          <tbody>
            {receipt.items.map(i => (
              <tr key={i.productId}><td>{i.nombre}</td><td>{fmtNum(i.qty)}</td><td>{money(i.unitPrice)}</td><td>{money(i.qty * i.unitPrice)}</td></tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center justify-between" style={{ padding: '12px 0', fontWeight: 700, fontSize: 15 }}>
          <span>Total</span><span>{money(receipt.total)}</span>
        </div>
      </div>
      <div className="flex gap-2" style={{ marginTop: 6 }}>
        <button onClick={onClose} style={secondaryBtn}>Cerrar</button>
        <button onClick={() => window.print()} style={primaryBtn}><Printer size={15} /> Imprimir</button>
      </div>
    </Modal>
  );
}
